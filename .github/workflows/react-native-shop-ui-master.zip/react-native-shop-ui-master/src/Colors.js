const Colors = {
  navbarBackgroundColor: '#2c3e50',
  statusBarColor: '#233240'
};

export default Colors;
